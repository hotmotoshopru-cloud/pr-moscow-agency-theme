document.addEventListener('DOMContentLoaded',function(){
 const b=document.querySelector('.mobile-toggle'),m=document.querySelector('#mobile-menu');
 if(b&&m){b.addEventListener('click',function(){const open=m.classList.toggle('open');b.setAttribute('aria-expanded',open?'true':'false');});}
});
